
public class ThreeCardPokerGame {
	Player playerOne;
	Player playerTwo;
	Dealer theDealer;
	
	public ThreeCardPokerGame() {
		playerOne = new Player();
		playerTwo = new Player();
		theDealer = new Dealer();
	}
}
